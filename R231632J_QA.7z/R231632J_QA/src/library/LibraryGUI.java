package src.library;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.time.Year;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class LibraryGUI extends JFrame {
    private LibraryManager manager;
    private JPanel mainPanel;
    private JTextField isbnField;
    private JTextField titleField;
    private JTextField authorField;
    private JTextField publisherField;
    private JTextField yearField;
    private JButton addButton;
    private JButton viewButton;
    private JButton updateButton;
    private JButton deleteButton;
    private JTable bookTable;
    private DefaultTableModel tableModel;

    private static final String LOG_FILE = "library_log.txt";

    public LibraryGUI() {
        manager = new LibraryManager();
        initializeUI();
        setupListeners();
    }

    private void initializeUI() {
        setContentPane(mainPanel);
        setTitle("Library Book Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        String[] columnNames = {"ISBN", "Title", "Author", "Publisher", "Year"};
        tableModel = new DefaultTableModel(columnNames, 0);
        bookTable.setModel(tableModel);
    }

    private void setupListeners() {
        addButton.addActionListener(e -> addBook());
        viewButton.addActionListener(e -> viewBooks());
        updateButton.addActionListener(e -> updateBook());
        deleteButton.addActionListener(e -> deleteBook());
    }

    private void addBook() {
        try {
            String isbn = validateISBN(isbnField.getText());
            String title = titleField.getText();
            String author = authorField.getText();
            String publisher = publisherField.getText();
            int year = validateYear(yearField.getText());

            Book book = new Book(isbn, title, author, publisher, year);
            manager.addBook(book);
            clearFields();
            viewBooks();
        } catch (IllegalArgumentException e) {
            logException(e);
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewBooks() {
        tableModel.setRowCount(0);
        List<Book> books = manager.getAllBooks();
        for (Book book : books) {
            Object[] row = {book.getIsbn(), book.getTitle(), book.getAuthor(), book.getPublisher(), book.getYear()};
            tableModel.addRow(row);
        }
    }

    private void updateBook() {
        try {
            String isbn = validateISBN(isbnField.getText());
            String title = titleField.getText();
            String author = authorField.getText();
            String publisher = publisherField.getText();
            int year = validateYear(yearField.getText());

            Book book = new Book(isbn, title, author, publisher, year);
            manager.updateBook(book);
            clearFields();
            viewBooks();
        } catch (IllegalArgumentException e) {
            logException(e);
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteBook() {
        try {
            String isbn = validateISBN(isbnField.getText());
            manager.deleteBook(isbn);
            clearFields();
            viewBooks();
        } catch (IllegalArgumentException e) {
            logException(e);
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        isbnField.setText("");
        titleField.setText("");
        authorField.setText("");
        publisherField.setText("");
        yearField.setText("");
    }

    private String validateISBN(String isbn) {
        if (isbn == null || isbn.trim().isEmpty()) {
            throw new IllegalArgumentException("ISBN cannot be empty");
        }

        return isbn.trim();
    }

    private int validateYear(String yearStr) {
        try {
            int year = Integer.parseInt(yearStr);
            int currentYear = Year.now().getValue();
            if (year < 0 || year > currentYear) {
                throw new IllegalArgumentException("Year must be between 0 and " + currentYear);
            }
            return year;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid year format");
        }
    }

    private void logException(Exception e) {
        LocalDateTime now = LocalDateTime.now();
        String timestamp = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String logMessage = String.format("%s - %s: %s%n", timestamp, e.getClass().getSimpleName(), e.getMessage());

        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            writer.print(logMessage);
        } catch (IOException ioException) {
            System.err.println("Error writing to log file: " + ioException.getMessage());
        }
    }
}
